rsconnect::deployApp(
  rprojroot::find_package_root_file("inst/examples/card"),
  appName = "card", account = "testing-apps"
)
