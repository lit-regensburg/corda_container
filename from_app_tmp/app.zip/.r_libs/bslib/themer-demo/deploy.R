rsconnect::deployApp(
  rprojroot::find_package_root_file("inst/themer-demo/deploy"),
  appName = "themer-demo", account = "testing-apps"
)
